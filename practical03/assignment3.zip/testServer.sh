#!/bin/bash

./assignment3 -l 12345 -p happy