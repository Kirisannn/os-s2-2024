#!/bin/bash
python tests.py

sleep 1

rm -f *.txt