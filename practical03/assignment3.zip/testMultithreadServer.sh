#!/bin/bash

pattern=$1

./assignment3 -l 12345 -p $pattern